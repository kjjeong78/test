from os.path import join, basename, splitext
import shutil
from annotation_generator import generate_annotations
from util.file_util import deep_search, file_func_mt, make_dir


def tlr_packaging(image_path, output_path, ext='bmp'):
    image_path = str(image_path).replace('\\', '/')
    output_path = str(output_path).replace('\\', '/')
    make_dir(output_path)

    annotation_path = join(output_path, 'Annotations')
    image_sets_path = join(output_path, 'ImageSets')
    jpeg_images_path = join(output_path, 'JPEGImages')
    make_dir(annotation_path)
    make_dir(image_sets_path)
    make_dir(jpeg_images_path)

    images = deep_search(image_path, ext)
    tlr_cls = list()

    for img in images:
        tl = [int(x) for x in splitext(basename(img))[0].split('(')[1].split(')')[0].split(',')]
        tlr_cls.append(tl)

    # Generate annotations
    generate_annotations(images, tlr_cls, annotation_path)

    # Copy images
    file_func_mt(shutil.copy, images, jpeg_images_path)

    # Write ImageSets text
    print('Write ImageSets text...')
    train_path = open(join(image_sets_path, 'all.txt'), 'w')
    for img_path in images:
        train_path.write('%s\n' % splitext(basename(img_path))[0])
    train_path.close()

    # Make tar
    print("Make tar...")
    shutil.make_archive(join(output_path, 'tlr_udb'), 'tar', output_path)

    # Remove directories
    print('Delete copied files...')
    shutil.rmtree(jpeg_images_path)
    shutil.rmtree(annotation_path)
    shutil.rmtree(image_sets_path)
