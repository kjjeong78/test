import os
from os.path import basename, splitext, abspath
import cv2
import ntpath
from multiprocessing.pool import ThreadPool
from jinja2 import Environment, FileSystemLoader
from util.file_util import divide_list, start_task, print_task, NUMBER_OF_THREADS


pool = ThreadPool(processes=NUMBER_OF_THREADS)


class Writer:

    def __init__(
            self,
            width,
            height):
        loader = FileSystemLoader(searchpath="./dict")
        environment = Environment(loader=loader)
        self.annotation_template = environment.get_template('annotation.xml')

        self.template_parameters = {
            'width': width,
            'height': height,
            'objects': []
        }

    def add_tlr_object(
            self,
            name,
            xmin,
            ymin,
            xmax,
            ymax,
            tl_cls):
        self.template_parameters['objects'].append({
            'name': name,
            'xmin': xmin,
            'ymin': ymin,
            'xmax': xmax,
            'ymax': ymax,
            'cls0': tl_cls[0],
            'cls1': tl_cls[1],
            'cls2': tl_cls[2],
            'cls3': tl_cls[3],
            'cls4': tl_cls[4],
        })

    def add_blob_cls_object(
            self,
            name,
            xmin,
            ymin,
            xmax,
            ymax):
        self.template_parameters['objects'].append({
            'name': name,
            'xmin': xmin,
            'ymin': ymin,
            'xmax': xmax,
            'ymax': ymax
        })

    def save(self, annotation_path):
        with open(annotation_path, 'w') as file:
            content = self.annotation_template.render(
                **self.template_parameters)
            file.write(content)


def generate_annotation_tlr(img_path, cls, output_path):
    for idx in range(len(img_path)):
        writer = Writer(32, 160)
        blob_n = 5
        for c in cls[idx]:
            if c == 4:
                blob_n -= 1
        writer.add_tlr_object(blob_n, 3, 3, 10, 10, cls[idx])  # TODO : need to feed none zero width and height
        output_name = os.path.join(output_path, (splitext(basename(img_path[idx]))[0] + '.xml'))
        writer.save(output_name)
        print_task()


def generate_annotation_blob(img_path, cls, output_path):
    for idx in range(len(img_path)):
        writer = Writer(32, 160)
        writer.add_blob_cls_object(cls[idx], 3, 3, 10, 10)  # TODO : need to feed none zero width and height
        output_name = os.path.join(output_path, (splitext(basename(img_path[idx]))[0] + '.xml'))
        writer.save(output_name)
        print_task()


def generate_annotations(image_paths, cls_list_per_image, output_dir, annotation_method = generate_annotation_tlr):
    start_task(len(image_paths))
    threads = list()
    src_division = divide_list(image_paths, NUMBER_OF_THREADS)
    cls_division = divide_list(cls_list_per_image, NUMBER_OF_THREADS)
    for idx in range(len(src_division)):
        threads.append(
            pool.apply_async(
                annotation_method,
                (src_division[idx], cls_division[idx], output_dir)
            )
        )
    for t in threads:
        t.get()
    return cls_list_per_image
