import caffe
import argparse
import cv2
import numpy as np
import shutil
from os.path import splitext, basename
from os.path import join, basename, isdir
from util.util_func import tlr_preprocessing, tlr_resize_and_pad
from util.caffe_util import Network
from util.file_util import make_dir, deep_search


original_images_path = r'D:\DB\TLR\51.cm_ger_tstld_rework_tlr (19.12.20)\images'
original_images_path = original_images_path.replace('\\', '/')
cropped_images_path = r'D:\DB\TLR\51.cm_ger_tstld_rework_tlr (19.12.20)\tl_crop'
cropped_images_path = cropped_images_path.replace('\\', '/')
# check_images_path = r'D:\DB\TLR\00.train_01_od_cm_ger_tlr (20.01.14)\check_images'
# check_images_path = check_images_path.replace('\\', '/')
image_with_tl_path = r'D:\DB\TLR\51.cm_ger_tstld_rework_tlr (19.12.20)\images_with_tl'
image_with_tl_path = image_with_tl_path.replace('\\', '/')

original_images = deep_search(original_images_path, ['jpg', 'bmp', 'jpeg', 'png'])
cropped_images = deep_search(cropped_images_path, ['jpg', 'bmp', 'jpeg', 'png'])

# for i in range(5):
#     make_dir(join(check_images_path, str(i + 1)))
whole = len(cropped_images)
for idx, cr_image in enumerate(cropped_images):
    print('%d/%d' % (idx + 1, whole))
    original_image_name = basename(cr_image).split('(')[0][:-3]
    tl = [int(t) for t in basename(cr_image).split('(')[1].split(')')[0].split(',')]
    n_blob = 5
    for t in tl:
        if t == 4:
            n_blob -= 1

    # blob_path = join(check_images_path, str(n_blob))
    # shutil.copy(cr_image, join(blob_path, splitext(basename(cr_image))[0] + '_' + str(n_blob) + '.bmp'))
    shutil.copy(join(original_images_path, original_image_name + '.jpg'), image_with_tl_path)

