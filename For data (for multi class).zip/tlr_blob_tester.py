import caffe
import argparse
import cv2
import numpy as np
import shutil
from os.path import splitext, basename
from os.path import join, basename, isdir
from util.util_func import tlr_preprocessing
from util.caffe_util import Network
from util.file_util import make_dir, deep_search


parser = argparse.ArgumentParser()

parser.add_argument('--input_dir', type=str, help='Path of directory which contains data',
                    default=r'D:\DB\TLR\00.train_01_od_cm_ger_tlr (20.01.14)\tl_crop')

parser.add_argument('--network', type=str, help='Path of model',
                    default=r'D:\GoogleDriveBack\StradVision\Utils\PycaffeTrainer\solvers_blob02\tlr_blob_network.prototxt')

parser.add_argument('--weights', type=str, help='Path of caffemodel',
                    default=r'D:\GoogleDriveBack\StradVision\Utils\PycaffeTrainer\solvers_blob02\snapshots\network\tlr_blob_iter_500000.caffemodel')

parser.add_argument('--num_bulb', type=int, help='Number of bulbs',
                    default=5)

parser.add_argument('--num_class', type=int, help='Number of class',
                    default=5)

parser.add_argument('--save', type=str, help='Save images or not',
                    default='false')

parser.add_argument('--gpu', type=int, help='Iteration of snapshots',
                    default=0)

args = parser.parse_args()

args.input_dir = str(args.input_dir).replace('\\', '/')
args.network = str(args.network).replace('\\', '/')
args.weights = str(args.weights).replace('\\', '/')

if isdir(args.weights):
    files = deep_search(str(args.weights), name_grep='caffemodel')
    args.weights = files[0]

# initialize the nets
caffe.set_device(0)
caffe.set_mode_gpu()
net = Network(model_path=args.network, weights=args.weights, phase=caffe.TEST)
image_list = deep_search(args.input_dir, ext_grep=['png', 'bmp', 'jpg', 'jpeg'])

num_blob = args.num_bulb
num_class = args.num_class
result_bulb = [[0] * num_blob for item in range(num_blob)]
result_l2_bulb = [[0] * num_blob for item in range(num_blob)]
blob_ratio = [0.92154134, 0.52681914, 0.39414071, 0.28048566, 0.23407153]

# for i in range(5):
#     make_dir(join(args.input_dir, str(i + 1)))
#     make_dir(join(args.input_dir, str(i + 1), 'correct'))
#     make_dir(join(args.input_dir, str(i + 1), 'wrong'))

# do training
num_img = len(image_list)
for idx, img_path in enumerate(image_list):
    origin = cv2.imread(img_path)
    h, w, c = origin.shape
    input_tensor = tlr_preprocessing(origin)

    # Run network
    net.blobs['data'].data[...] = input_tensor
    net.forward()
    prob = net.blobs['fc_out'].data[0]

    # GT Class
    tl = [int(x) for x in splitext(basename(img_path))[0].split('(')[1].split(')')[0].split(',')]

    n_blob = 0
    n_predict_blob = 0
    for b in range(num_blob):
        predict = 0
        for c in range(1, num_class):
            if prob[predict] < prob[c]:
                predict = c
        cls = tl[b]
        if cls != 4:
            n_blob += 1
        n_predict_blob = predict + 1

    result_bulb[n_blob - 1][n_predict_blob - 1] += 1

    cur_ratio = float(w) / float(h)
    min_ratio_err = 10
    min_ratio_idx = 0
    for b in range(num_blob):
        cur_ratio_err = pow(cur_ratio - blob_ratio[b], 2.0)
        if min_ratio_err > cur_ratio_err:
            min_ratio_err = cur_ratio_err
            min_ratio_idx = b

    result_l2_bulb[n_blob - 1][min_ratio_idx] += 1

    # shutil.copy(img_path, join(args.input_dir, str(n_blob)))

    # if n_blob != n_predict_blob:
    #     # print(basename(img_path), n_bulb, n_predict_bulb)
    #     # cv2.imshow('Image', origin)
    #     # cv2.waitKey()
    #     shutil.copy(img_path, join(args.input_dir, str(n_blob), 'wrong', str(n_predict_blob) + '_' + basename(img_path)))
    # else:
    #     # print('correct')
    #     shutil.copy(img_path, join(args.input_dir, str(n_blob), 'correct', str(n_predict_blob) + '_' + basename(img_path)))

    if idx % 1000 == 0 and idx != 0:
        print("Result" + str(idx))

        for c, r in enumerate(result_bulb):
            temp = ''
            temp_sum = 0
            for rr in r:
                temp += str(rr) + '\t'
                temp_sum += rr
            print(temp + str(temp_sum if temp_sum == 0 else float(r[c]) / float(temp_sum)))

        print('L2 blob')

        for c, r in enumerate(result_l2_bulb):
            temp = ''
            temp_sum = 0
            for rr in r:
                temp += str(rr) + '\t'
                temp_sum += rr
            print(temp + str(temp_sum if temp_sum == 0 else float(r[c]) / float(temp_sum)))

        # for b_idx, b in enumerate(result_bulb):
        #     print(b_idx + 1, b[0], b[1], b[1] if b[1] == 0 else float(b[0]) / float(b[1]))

print("Result" + str(num_img))

for c, r in enumerate(result_bulb):
    temp = ''
    temp_sum = 0
    for rr in r:
        temp += str(rr) + '\t'
        temp_sum += rr
    print(temp + str(temp_sum if temp_sum == 0 else float(r[c]) / float(temp_sum)))

print('L2 blob')

for c, r in enumerate(result_l2_bulb):
    temp = ''
    temp_sum = 0
    for rr in r:
        temp += str(rr) + '\t'
        temp_sum += rr
    print(temp + str(temp_sum if temp_sum == 0 else float(r[c]) / float(temp_sum)))

# for b_idx, b in enumerate(result_bulb):
#     print(b_idx + 1, b[0], b[1], b[1] if b[1] == 0 else float(b[0]) / float(b[1]))
