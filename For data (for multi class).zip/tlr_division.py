from os.path import join, basename, splitext, dirname
import shutil
import argparse
import cv2
from util.file_util import gather_dirs, gather_files, deep_search, file_func_mt, make_dir, NUMBER_OF_THREADS


parser = argparse.ArgumentParser()

parser.add_argument('--image_path', type=str, help='Source path of images',
                    default=r'D:\DB\TLR\00.train_01_od_cm_ger_tlr (20.01.14)\tl_crop')

parser.add_argument('--output_path', type=str, help='Source path of images',
                    default=r'D:\DB\TLR\00.train_01_od_cm_ger_tlr (20.01.14)\tl_32')

args = parser.parse_args()

args.image_path = str(args.image_path).replace('\\', '/')
images = deep_search(args.image_path, ext_grep=['jpg', 'png', 'bmp', 'jpeg'])
image_names = [basename(name) for name in images]


for idx, img_path in enumerate(images):
    img = cv2.imread(img_path)
    h, w, c = img.shape
    if w >= 32:
        shutil.copy(img_path, join(args.output_path, image_names[idx]))

