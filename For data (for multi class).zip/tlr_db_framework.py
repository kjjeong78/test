from os.path import join
from tlr_fullsize_augment_and_crop import tlr_fullsize_crop_and_augment
from tlr_augment_by_blobs import tlr_augment_by_num_blobs
from tlr_resizing_and_pad import tlr_resize_and_padding
from tlr_packaging import tlr_packaging

root_dir = r'F:\TLR\DB\train'
image_folder = 'images_daytime'
gt_folder = 'gt_xml_tlr_20200210_r01'
version = r'day_rnd_crop0.1_min16'

# tlr_fullsize_crop_and_augment(
#     image_path=join(root_dir, image_folder),
#     xml_path=join(root_dir, gt_folder),
#     output_path=root_dir + r'\tl_crop_' + version,
#     to_augment=True,
#     least_size=16
# )

# tlr_augment_by_num_blobs(
#     image_path=root_dir + r'\tl_crop_' + version,
#     output_path=root_dir + r'\tl_blob_' + version
# )

tlr_resize_and_padding(
    image_path=root_dir + r'\tl_crop_' + version,
    #output_path=root_dir + r'\tl_resize_' + version
    output_path=root_dir + r'\tl_cut_' + version
)

tlr_cut(
    image_path=root_dir + r'\tl_crop_' + version,
    output_path=root_dir + r'\tl_cut_' + version
)

tlr_packaging(
    image_path=root_dir + r'\tl_resize_' + version,
    output_path=root_dir + r'\tl_packaging_' + version,
)
