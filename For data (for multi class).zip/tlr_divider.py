from os.path import basename, join
from shutil import copy
from util.file_util import deep_search, make_dir


path = r'D:\DB\TLR\51.cm_ger_tstld_rework_tlr (19.12.20)\tl_crop_day_except_small_original'

image_files = deep_search(path, ['bmp', 'jpg', 'jpeg', 'png'])
num_blob = 5
num_class = 5

for b in range(num_blob):
    make_dir(join(path, 'blob' + str(b + 1)))
for c in range(num_class):
    make_dir(join(path, 'class' + str(c)))

for img_path in image_files:
    tl_cls = [int(c) for c in basename(img_path).split('(')[1].split(')')[0].split(',')]
    n_blob = 5
    cls = 0
    for tl in tl_cls:
        if tl == 4:
            n_blob -= 1
        if tl != 4 and tl > cls:
            cls = tl

    copy(img_path, join(path, 'class' + str(cls)))
    copy(img_path, join(path, 'blob' + str(n_blob)))



