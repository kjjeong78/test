import os
from os.path import join, basename, splitext, dirname
import ntpath
import cv2
from util.util_func import divide_list, start_task, print_task
from multiprocessing.pool import ThreadPool
from multiprocessing import cpu_count
from errno import EPERM, EACCES
import numpy as np


NUMBER_OF_THREADS = cpu_count()
pool = ThreadPool(processes=NUMBER_OF_THREADS)


def make_dir(dst):
    try:
        os.makedirs(dst)
    except WindowsError:
        # print('[%s] already exist' % dst)
        pass


# Check file extension
def check_ext(file_name, ext_grep):
    """
    Check extension of file
    :param file_name: Path or name of file
    :param ext_grep: Extension grep
    :return: File extension is equal to ext_grep or not
    """
    ext = file_name.split('.')[-1]
    if type(ext_grep) == str:
        return (ext_grep.lower() == ext.lower() or ext_grep == 'ALL') and True or False
    elif type(ext_grep) == list:
        for ext_g in ext_grep:
            if ext_g.lower() == ext.lower():
                return True
        return False


# Search whole subdirectories of directory
def deep_search(dir_name, ext_grep='ALL', name_grep='ALL', dir_grep='ALL'):
    """
    Gather wholes files in sub directories
    :param dir_name: Name of root directory
    :param ext_grep: Extension grep
    :param name_grep: Name grep
    :param dir_grep: Directory grep
    :return: File list
    """
    file_list = list()
    for (path, dir, files) in os.walk(dir_name):
        try:
            for _file in files:
                if (name_grep == 'ALL' or _file.find(name_grep) != -1) and check_ext(_file, ext_grep):
                    if dir_grep == 'ALL' or dirname(os.path.join(path, _file)).split('\\')[-1] == dir_grep:
                        file_list.append(os.path.join(path, _file))
        except EPERM or EACCES:
            pass

    return file_list


# Search directories
def deep_search_dir(dir_name, name_grep='ALL'):
    """
    Gather wholes files in sub directories
    :param dir_name: Name of root directory
    :param ext_grep: Extension grep
    :param name_grep: Name grep
    :return: File list
    """
    dir_list = list()
    for (path, dir, files) in os.walk(dir_name):
        try:
            for _dir in dir:
                if name_grep == 'ALL' or _dir.find(name_grep) != -1:
                    dir_list.append(os.path.join(path, _dir))

        except EPERM or EACCES:
            pass

    return dir_list


def gather_files(dir_name, ext_grep='ALL'):
    """
    Gather files in directory
    :param dir_name: Name of directory
    :param ext_grep: Extension grep
    :return: File list
    """

    file_list = list()
    try:
        for f in os.listdir(dir_name):
            if os.path.isfile(os.path.join(dir_name, f)) and check_ext(f, ext_grep):
                file_list.append(os.path.join(dir_name, f))
    except WindowsError:
        return file_list

    return file_list


def gather_dirs(dir_name):
    """
    Gather whole sub directories paths
    :param dir_name: Name of root directory
    :return: List of sub directories
    """
    dir_list = list()
    for (path, dir, files) in os.walk(dir_name):
        try:
            for _dir in dir:
                dir_list.append(os.path.join(path, _dir))

        except EPERM or EACCES:
            pass

    return dir_list


CONDITION_VAL = dict()


def make_dst_list_from_src_list(src_list, dst_dir):
    dst_list = list()
    for s in src_list:
        dst_list.append(join(dst_dir, basename(s)))

    return dst_list


def image_sharpness_condition(src):
    global CONDITION_VAL
    img = cv2.imread(src, cv2.CV_8U)
    if img is None:
        return False
    height, width = img.shape
    img_arr = np.asarray(img, dtype=np.int32)
    gy, gx = np.gradient(img_arr)
    gnorm = np.sqrt(gx**2 + gy**2)
    sharpness = np.average(gnorm)
    if sharpness >= CONDITION_VAL['score'] and height >= CONDITION_VAL['size'] and width >= CONDITION_VAL['size']:
        return True
    else:
        return False


def image_blur_condition(src):
    global CONDITION_VAL
    img = cv2.imread(src, cv2.CV_8U)
    if img is None:
        return False
    height, width = img.shape
    img_arr = np.asarray(img, dtype=np.int32)
    gy, gx = np.gradient(img_arr)
    gnorm = np.sqrt(gx**2 + gy**2)
    sharpness = np.average(gnorm)
    intensity = np.mean(img)
    if sharpness <= CONDITION_VAL['score'] and height >= CONDITION_VAL['size'] and width >= CONDITION_VAL['size'] and\
            CONDITION_VAL['intensity'] <= intensity:
        return True
    else:
        return False


def image_size_condition(src):
    global CONDITION_VAL
    img = cv2.imread(src)
    height, width, _ = img.shape
    if width >= CONDITION_VAL['size'] and height >= CONDITION_VAL['size']:
        return True
    else:
        return False


def file_size_condition(src):
    global CONDITION_VAL
    file_size = os.path.getsize(src) / 1024
    if file_size >= CONDITION_VAL['size']:
        return True
    else:
        return False


def file_to_file(file_func, src, dst, condition=None):
    """
    Copy file to destination
    :param file_func: Function about file (ex, shutil.copy)
    :param src: Path of file
    :param dst: Destination of file
    :param condition: Condition function to do file_func or not
    :return:
    """
    if not os.path.exists(os.path.split(dst)[0]):
        make_dir(os.path.split(dst)[0])
    if condition is not None and not condition(src):
        return
    try:
        file_func(src, dst)
    except Exception as e:
        print(e.message)


def file_to_dir(file_func, src, dst, condition=None):
    """
    Copy file to destination directory
    :param file_func: Function about file (ex, shutil.copy)
    :param src: Path of file
    :param dst: Destination directory
    :param condition: Condition function to do file_func or not
    :return: Return destination path of file
    """
    return file_to_file(file_func, src, os.path.join(dst, ntpath.basename(src)), condition)


def files_to_dir(file_func, file_list, dst, print_func=None, condition=None):
    """
    Copy files to destination directory
    :param file_func: Function about file (ex, shutil.copy)
    :param file_list: Path of files
    :param dst: Destination directory
    :param print_func: Print function
    :param condition: Condition function to do file_func or not
    :return:
    """
    if not os.path.exists(dst):
        make_dir(dst)
    for f in file_list:
        file_to_dir(file_func, f, dst, condition)
        if print_func is not None:
            print_func()


def files_to_files(file_func, src_list, dst_list, print_func=None, condition=None):
    """
    Copy files to destination directory
    :param file_func: Function about file (ex, shutil.copy)
    :param src_list: Path of files
    :param dst_list: Path of destinations
    :param print_func: Print function
    :param condition: Condition function to do file_func or not
    :return:
    """
    for s, d in zip(src_list, dst_list):
        file_to_file(file_func, s, d, condition)
        if print_func is not None:
            print_func()


def file_func_mt(file_func, src_list, dst_list_or_dst, condition=None):
    """
    Copy files with multi threading
    :param file_func: Function about file (ex, shutil.copy)
    :param src_list: List of paths of files
    :param dst_list_or_dst: List of paths of files or destination directory
    :param condition: Condition function to do file_func or not
    :return:
    """
    start_task(len(src_list))
    threads = list()
    src_division = divide_list(src_list, NUMBER_OF_THREADS)
    if isinstance(dst_list_or_dst, list):
        if len(src_list) != len(dst_list_or_dst):
            print('Size of source list and destination list are different!')
            exit(1)
        dst_division = divide_list(dst_list_or_dst, NUMBER_OF_THREADS)

        for sd, dd in zip(src_division, dst_division):
            threads.append(pool.apply_async(
                files_to_files,
                (file_func, sd, dd, print_task, condition)
            ))

    elif isinstance(dst_list_or_dst, str):
        for sd in src_division:
            threads.append(pool.apply_async(
                files_to_dir,
                (file_func, sd, dst_list_or_dst, print_task, condition)
            ))
    else:
        print('Cannot recognize [%s]' % dst_list_or_dst)
        exit(1)

    for t in threads:
        t.get()

