import sys
from time import time
from math import ceil
from multiprocessing import Semaphore
import cv2
import numpy as np

number_of_task = 0
current_task = 0
sm = Semaphore(1)


def image_to_tensor(img):
    img = img.astype(np.float)
    img = np.expand_dims(img, 0)
    img = np.transpose(img, [0, 3, 1, 2])
    return img

def tlr_cut_and_return(img, bulb_cnt):
    h, w, c = img.shape
    divide_h = h / bulb_cnt
    img0 = img[0 : divide_h, 0 : w]
    img1 = img[divide_h + 1 : divide_h * 2, 0 : w]
    img2 = img[divide_h * 2 + 1 : h, 0 : w]

    cv2.imwrite('./origin.jpg', img)
    cv2.imwrite('./0.jpg', img0)
    cv2.imwrite('./1.jpg', img1)
    cv2.imwrite('./2.jpg', img2)

    result = list()
    result.append(img0)
    result.append(img1)
    result.append(img2)

    return result

def tlr_resize_and_pad(img, width=32, height=160, mean0=102.980103, mean1=115.946503, mean2=122.771698):
    h, w, c = img.shape
    resized_width = width
    resized_height = int(float(h) * (float(resized_width) / float(w)))
    resized_height = resized_height if resized_height < height else height
    img = cv2.resize(img, (int(resized_width), int(resized_height)), interpolation=cv2.INTER_LINEAR)
    pad = height - resized_height
    img = cv2.copyMakeBorder(img, 0, int(pad), 0, 0, cv2.BORDER_CONSTANT, value=[mean0, mean1, mean2])
    return img


def tlr_preprocessing(img, width=32, height=160, mean0=102.980103, mean1=115.946503, mean2=122.771698):
    img = tlr_resize_and_pad(img, width, height, mean0, mean1, mean2)
    img = img.astype(np.float)
    img[:, :, 0] -= mean0
    img[:, :, 1] -= mean1
    img[:, :, 2] -= mean2
    img = image_to_tensor(img)
    return img


def print_function(string):
    sys.stdout.write('\r' + string)
    sys.stdout.flush()


def divide_list(task_list, n_worker):
    """
    Divide tasks per worker
    :param task_list: List of whole tasks
    :param n_worker: Number of workers
    :return: Division list
    """
    division = list()
    n_list = len(task_list)
    division_size = int(ceil(float(n_list)/float(n_worker)))
    for t in range(n_worker):
        end = ((t + 1) * division_size)
        end = end if end <= n_list else n_list
        division.append(task_list[t * division_size:end])
        if end == n_list:
            break

    return division


def start_task(number_of_tasks):
    global current_task
    global number_of_task
    current_task = 1
    number_of_task = number_of_tasks


def print_task():
    global current_task
    global number_of_task
    global sm
    print_function('%d / %d' % (current_task, number_of_task))
    if current_task == number_of_task:
        print('')
    sm.acquire()
    current_task += 1
    sm.release()


class Timer:

    def __init__(self, as_progress_notifier=True):
        """
        Thread safe Timer class.
        If set as_progress_notifier = True, then it will be use to check progress of some processes.
        If not it will be use to simple timer.
        :param as_progress_notifier:
        """
        self.whole_number_of_data = 0
        self.start_progress = 0
        self.current_progress = 0
        self.time_moving_average = 0
        self.elapsed_time = 0
        self.remain_time = 0
        self.tick_start_time = 0
        self.is_progress_notifier = as_progress_notifier
        self.timer_ready = False
        self.print_fn = self.timer_print
        self.locker = Semaphore(1)

    def timer_print(self):
        sys.stdout.write('\rTimer : [%d/%d][%.2f%%][%d hour %d minute %d second left]' %
                         (self.current_progress, self.whole_number_of_data,
                          float(self.current_progress) / float(self.whole_number_of_data) * 100,
                          int(self.remain_time / 3600), int(self.remain_time / 60) % 60, self.remain_time % 60))
        sys.stdout.flush()

    def start(self, number_of_data=None, start_progress=None):
        if self.is_progress_notifier:
            if number_of_data is None:
                raise ValueError('You should feed number_of_data.')
            self.whole_number_of_data = number_of_data
            self.start_progress = 0 if start_progress is None else start_progress
            self.current_progress = 0 if start_progress is None else start_progress
            self.timer_ready = True
            self.tick_start_time = time()
        else:
            self.tick_start_time = time()
            self.timer_ready = True

    def tick_timer(self):
        self.locker.acquire()
        if not self.timer_ready:
            raise AttributeError('Need to initialize timer by init_timer().')
        if not self.is_progress_notifier:
            raise AttributeError('You should set as_progress_notifier to True if you want to use tick_timer().')

        if self.current_progress == self.start_progress:
            self.time_moving_average = time() - self.tick_start_time
        else:
            tick = time() - self.tick_start_time
            self.elapsed_time = self.current_progress * self.time_moving_average
            self.time_moving_average = (self.elapsed_time + tick) / (self.current_progress + 1)

        self.current_progress += 1
        self.remain_time = (self.whole_number_of_data - self.current_progress) * self.time_moving_average

        if self.print_fn is not None:
            self.print_fn()

        self.tick_start_time = time()
        self.locker.release()

    def check(self, start_timer=True):
        self.locker.acquire()
        if self.is_progress_notifier:
            raise AttributeError('You should set as_progress_notifier to False if you want to use check().')
        self.elapsed_time = time() - self.tick_start_time

        if self.print_fn is not None:
            self.print_fn()

        if start_timer:
            self.start(self.whole_number_of_data)
        self.locker.release()
