import caffe
from os.path import join, splitext, basename, isdir, exists, dirname
from os import listdir, remove
import copy
import time
import sys
from multiprocessing import Semaphore, Lock
import numpy as np
from collections import OrderedDict
import visdom
from util.file_util import deep_search, make_dir
from shutil import move, rmtree, copy2

from multiprocessing.pool import ThreadPool
from multiprocessing import cpu_count

NUMBER_OF_THREADS = cpu_count()
pool = ThreadPool(processes=NUMBER_OF_THREADS)


class Timer:

    def __init__(self, display_every=0, inline_print=True, as_progress_notifier=True):
        """
        Thread safe Timer class.
        If set as_progress_notifier = True, then it will be use to check progress of some processes.
        If not it will be use to simple timer.
        :param as_progress_notifier:
        """
        self.whole_number_of_data = 0
        self.start_progress = 0
        self.current_progress = 0
        self.time_moving_average = 0
        self.elapsed_time = 0
        self.remain_time = 0
        self.tick_start_time = 0
        self.is_progress_notifier = as_progress_notifier
        self.timer_ready = False
        self.print_fn = self.timer_print
        self.locker = Semaphore(1)
        self.inline_print = inline_print
        self.display_every = display_every

    def left_time(self):
        return [int(self.remain_time / 3600), int(self.remain_time / 60) % 60, self.remain_time % 60]

    def timer_print(self):
        message = '\rTimer : [%d/%d][%.2f%%][%d hour %d minute %d second left]' %\
                  (self.current_progress, self.whole_number_of_data,
                   float(self.current_progress) / float(self.whole_number_of_data) * 100,
                   int(self.remain_time / 3600), int(self.remain_time / 60) % 60, self.remain_time % 60)
        return message

    def print_out(self):
        if self.inline_print:
            sys.stdout.write(self.print_fn())
            sys.stdout.flush()
        else:
            print(self.print_fn())

    def start(self, number_of_data=None, start_progress=None):
        if self.is_progress_notifier:
            if number_of_data is None:
                raise ValueError('You should feed number_of_data.')
            self.whole_number_of_data = number_of_data
            self.start_progress = 0 if start_progress is None else start_progress
            self.current_progress = 0 if start_progress is None else start_progress
            self.timer_ready = True
            self.tick_start_time = time.time()
        else:
            self.tick_start_time = time.time()
            self.timer_ready = True

    def tick_timer(self):
        self.locker.acquire()
        if not self.timer_ready:
            raise AttributeError('Need to initialize timer by start().')
        if not self.is_progress_notifier:
            raise AttributeError('You should set as_progress_notifier to True if you want to use tick_timer().')

        if self.current_progress == self.start_progress:
            self.time_moving_average = time.time() - self.tick_start_time
        else:
            tick = time.time() - self.tick_start_time
            self.elapsed_time = (self.current_progress - self.start_progress) * self.time_moving_average
            self.time_moving_average = (self.elapsed_time + tick) / (self.current_progress - self.start_progress + 1)

        self.current_progress += 1
        self.remain_time = (self.whole_number_of_data - self.current_progress) * self.time_moving_average

        if self.display_every != 0 and self.print_fn is not None and self.current_progress % self.display_every == 0:
            self.print_out()

        self.tick_start_time = time.time()
        self.locker.release()

    def check(self, start_timer=True):
        self.locker.acquire()
        if self.is_progress_notifier:
            raise AttributeError('You should set as_progress_notifier to False if you want to use check().')
        self.elapsed_time = time.time() - self.tick_start_time

        if self.print_fn is not None:
            self.print_fn()

        if start_timer:
            self.start(self.whole_number_of_data)
        self.locker.release()


def clamp_image(img, min_value=0.0, max_value=255.0):
    img[img > max_value] = max_value
    img[img < min_value] = min_value
    return img


def tanh_to_image(img):
    img += 1.0
    img *= 127.5
    img[img > 255] = 255
    img[img < 0] = 0
    return img


def print_blob(net, blob_name, msg):
    blob_data = np.copy(net.blobs[blob_name].data)
    blob_diff = np.copy(net.blobs[blob_name].diff)
    print('\t[%s][blob=%s]' % (msg, blob_name))
    print('\tData\t%20.15f, %20.15f, %20.15f' % (
        np.max(blob_data),
        np.min(blob_data),
        float(np.mean(blob_data))))
    print('\tDiff\t%20.15f, %20.15f, %20.15f' % (
        np.max(blob_diff),
        np.min(blob_diff),
        float(np.mean(blob_diff))))


def print_param(net, param_name, msg):
    print('\t[%s][param=%s]' % (msg, param_name))
    print('\tData\t%20.15f, %20.15f' % (
        np.max(net.params[param_name][0].data),
        np.min(net.params[param_name][0].data)))
    print('\tDiff\t%20.15f, %20.15f' % (
        np.max(np.copy(net.params[param_name][0].diff)),
        np.min(np.copy(net.params[param_name][0].diff))))


def auto_restore(solver, class_name=None, snapshot_dir=None, snapshot_path=None, weight_path=None,
                 mode='recent', desc=True):
    """
    Automatically restore solverstate which is recently updated or have most best performance.
    :param solver:
    :param class_name:
    :param snapshot_dir:
    :param snapshot_path:
    :param weight_path:
    :param mode: 'recent' or 'performance'. If solverstate saved by SmartModelSaver and [mode] set to 'performance',
    it automatically restore which have best performance
    :param desc: Need to get highest performance or lowest
    :return:
    """

    if snapshot_path is not None:  # Restore solverstate
        print('Restore snapshot from [%s]' % snapshot_path)
        solver.restore(snapshot_path)
    elif weight_path is not None:  # Restore weights
        print('Restore weights from [%s]' % weight_path)
        solver.net.copy_from(weight_path)
    elif snapshot_dir is not None:  # Auto restore recent states
        snapshots = deep_search(snapshot_dir, ext_grep='solverstate', name_grep=class_name)
        idx = 0
        while True:
            if len(snapshots) == idx:
                break
            if basename(snapshots[idx]).find(class_name + '_') != 0:
                snapshots.pop(idx)
            else:
                idx += 1

        mode = mode.lower()
        if mode == 'recent':
            last_snapshot_iter = 0
            last_snapshot = ''
            for s in snapshots:
                snap_name = splitext(basename(s))[0]
                i = int(snap_name.split('_')[-1])
                if last_snapshot_iter < i:
                    last_snapshot_iter = i
                    last_snapshot = s
            if last_snapshot_iter > 0:
                print('Auto restore recent snapshots from [%s]' % (snapshot_dir + '/' + last_snapshot))
                solver.restore(last_snapshot)
        elif mode == 'performance':
            def get_key(snap_path):
                return float(dirname(snap_path).split('_')[-1])

            idx = 0
            while idx != len(snapshots):
                try:
                    get_key(snapshots[idx])
                    idx += 1
                except ValueError:
                    snapshots.pop(idx)

            snapshots.sort(key=get_key, reverse=desc)
            if len(snapshots) > 0:
                model_path = splitext(snapshots[0])[0] + '.caffemodel'
                temp_model_path = join(snapshot_dir, basename(model_path))
                copy2(model_path, temp_model_path)
                auto_restore(solver, class_name, snapshot_path=snapshots[0])
                remove(temp_model_path)
        else:
            print('Cannot automatically restore snapshots, you must feed proper mode!')
            exit(1)


class SmartModelSaver:

    def __init__(self, solver, snapshot_dir, class_name, num_to_save=5, desc=True, precision=3):
        self.dir = snapshot_dir
        self.solver = solver
        self.class_name = class_name
        self.num_to_save = num_to_save
        self.desc = desc
        self.best_performance = list()
        self.check_set = set()
        self.precision = precision
        self.setup()

    def setup(self):
        dirs = listdir(self.dir)
        for d in dirs:
            temp_path = join(self.dir, d)
            if isdir(temp_path) and d.find(self.class_name) == 0:
                temp_performance = float(basename(temp_path).split('_')[-1])
                self.best_performance.append(temp_performance)
                self.check_set.add(temp_performance)

        self.best_performance.sort(reverse=self.desc)

    def _round(self, performance):
        return round(performance, self.precision)

    def snapshot_path(self, performance):
        _format = '%s_%' + '.%d' % self.precision + 'f'
        return _format % (self.class_name, self._round(performance))

    def smart_snapshot(self, test_performance):
        test_performance = self._round(test_performance)
        if len(self.best_performance) < self.num_to_save or self.best_performance[-1] <= test_performance:
            if test_performance not in self.check_set:
                self.best_performance.append(test_performance)
                self.check_set.add(test_performance)
                self.best_performance.sort(reverse=self.desc)

            if len(self.best_performance) > self.num_to_save:
                folder_to_delete = join(self.dir, self.snapshot_path(self.best_performance[-1]))
                if exists(folder_to_delete):
                    rmtree(folder_to_delete)
                self.check_set.remove(self.best_performance[-1])
                self.best_performance.pop()

            self.solver.snapshot()
            file_name = self.class_name + '_iter_' + str(self.solver.cur_iter())
            src_path = join(self.dir, file_name)
            src_ss = src_path + '.solverstate'
            src_cm = src_path + '.caffemodel'
            dst_dir = join(self.dir, self.snapshot_path(test_performance))
            dst_ss = join(dst_dir, file_name) + '.solverstate'
            dst_cm = join(dst_dir, file_name) + '.caffemodel'
            make_dir(dst_dir)
            move(src_ss, dst_ss)
            move(src_cm, dst_cm)


class Network:
    def __init__(self, network=None, model_path=None, weights=None, phase=caffe.TEST):
        if model_path is not None:
            print('Load network %s' % (basename(model_path)))
            self.net = caffe.Net(model_path, phase)
        elif network is not None:
            print('Load network')
            self.net = network
        else:
            print('Need to initialize net with caffe network or model path')
            exit(1)

        if weights is not None:
            self.copy_from(weights)
        self.blobs = self.net.blobs
        self.params = self.net.params
        self.layer_dict = self.net.layer_dict

    def blob(self, name):
        return self.net.blobs[name]

    def param(self, name):
        return self.net.params[name]

    def forward(self, blobs=None, start=None, end=None, refine_loops=0, **kwargs):
        self.net.forward(blobs, start, end, refine_loops, **kwargs)

    def backward(self, diffs=None, start=None, end=None, **kwargs):
        self.net.backward(diffs, start, end, **kwargs)

    def clear_param_diffs(self):
        self.net.clear_param_diffs()

    def share_with(self, network):
        self.net.share_with(network.net)

    def copy_from(self, weights_path):
        print('Load weights from %s' % weights_path)
        self.net.copy_from(weights_path)

    def save(self, weights_path):
        print('Save weights to %s' % weights_path)
        self.net.save(weights_path)


class Solver:
    def __init__(self, solver_type, solver_path, gpu=0):
        if type(gpu) is int:
            caffe.set_device(gpu)
        elif type(gpu) is list:
            print('Multi gpu not implemented yet')
            exit(1)
        caffe.set_mode_gpu()
        self.solver = solver_type(solver_path)
        self.display_every = self.solver.param.display
        self.test_interval = self.solver.param.test_interval
        self.test_iter = -1
        if self.test_interval != 0:
            self.test_iter = self.solver.param.test_iter(0)
        self.max_iter = self.solver.param.max_iter
        self.snapshot_every = self.solver.param.snapshot

        self.net = Network(network=self.solver.net)
        self.test_nets = [Network(network=x) for x in self.solver.test_nets]

    def cur_iter(self):
        return self.solver.iter

    def learning_rate(self):
        return self.solver.lr

    def restore(self, snapshot_path):
        self.solver.restore(snapshot_path)

    def snapshot(self):
        self.solver.snapshot()

    def increment_iter(self):
        self.solver.increment_iter()

    def apply_update(self):
        self.solver.apply_update()


class Visualizer:
    def __init__(self, port=8097, legend='main'):
        """
        Visualize data by visdom. You should turn on visdom server for visualize.
        :param port: Port number for visdom
        :param legend: Legend for visdom
        """
        self.vis = visdom.Visdom(port=port, env=legend)
        self.legend = legend
        self.mutex = Lock()

    def has_window(self, win):
        return self.vis.win_exists(win, self.legend)

    def close_win(self, win):
        self.vis.close(win, self.legend)

    def text_visualize(self, key, text):
        self.vis.text(text=text, win=key, env=self.legend)

    def line_visualize_async(self, key, it, value, update='append'):
        pool.apply_async(
            self.line_visualize,
            (key, it, value, update)
        )

    def line_visualize(self, key, it, value, update='append'):
        with self.mutex:
            if self.vis is not None:
                self.vis.line(X=it, Y=value, update=update,
                              win=key,
                              env=self.legend,
                              name=self.legend,
                              opts=dict(legend=[self.legend],
                                        title=key,
                                        xlabel='iter',
                                        ylabel=key))

    def image_visualize_async(self, win, captions, images, nrow=None, bgr=False, min_value=0.0, max_value=255.0):
        pool.apply_async(
            self.image_visualize,
            (win, captions, images, nrow, bgr, min_value, max_value)
        )

    def image_visualize(self, win, captions, images, nrow=None, bgr=False, min_value=0.0, max_value=255.0):
        with self.mutex:
            for i in range(len(images)):
                if bgr:
                    images[i] = np.transpose(images[i], [1, 2, 0])
                    images[i] = images[i][..., ::-1]
                    images[i] = np.transpose(images[i], [2, 0, 1])
                if min_value != 0.0 or max_value != 255.0:
                    images[i] = (images[i] - min_value) / (max_value - min_value) * 255.0
                    images[i] = clamp_image(images[i])
                images[i] = np.expand_dims(images[i].astype(np.uint8), 0)
            images = np.concatenate(images, axis=0)
            self.vis.images(
                tensor=images,
                nrow=len(images) if nrow is None else nrow,
                win=win,
                env=self.legend,
                opts=dict(
                    caption=captions,
                    title=win
                )
            )

    def deblur_visualize_async(self, win, captions, input_img, output_img, gt_img, nrow=None, bgr=False, min_value=0.0, max_value=255.0):
        pool.apply_async(
            self.deblur_visualize,
            (win, captions, input_img, output_img, gt_img, nrow, bgr, min_value, max_value)
        )

    def deblur_visualize(self, win, captions, input_img, output_img, gt_img, nrow=None, bgr=False, min_value=0.0, max_value=255.0):
        with self.mutex:
            difference_img = np.abs(input_img - output_img)
            difference_img2 = np.abs(gt_img - output_img)
            images = [input_img, difference_img, output_img, difference_img2, gt_img]
            for i in range(len(images)):
                if bgr:
                    images[i] = np.transpose(images[i], [1, 2, 0])
                    images[i] = images[i][..., ::-1]
                    images[i] = np.transpose(images[i], [2, 0, 1])
                if min_value != 0.0 or max_value != 255.0:
                    images[i] = (images[i] - min_value) / (max_value - min_value) * 255.0
                    images[i] = clamp_image(images[i])
                images[i] = np.expand_dims(images[i].astype(np.uint8), 0)
            images = np.concatenate(images, axis=0)
            self.vis.images(
                tensor=images,
                nrow=len(images) if nrow is None else nrow,
                win=win,
                env=self.legend,
                opts=dict(
                    caption=captions,
                    title=win
                )
            )

    def heatmap_visualize_async(self, win, tensor):
        pool.apply_async(
            self.heatmap_visualize,
            (win, tensor)
        )

    def heatmap_visualize(self, win, tensor):
        with self.mutex:
            tensor = np.flip(tensor, 0)
            self.vis.heatmap(
                X=tensor,
                win=win,
                env=self.legend,
                opts=dict(
                    colormap='Jet',
                    title=win
                )
            )

    def stem(self, win, tensor):
        self.vis.stem(
            X=tensor,
            win=win,
            env=self.legend,
            opts=dict(
                colormap='Jet',
                title=win
            )
        )

    def show_blob_avg(self, net, blob_name):
        _blob = net.blobs[blob_name].data[0]
        _temp = np.zeros(_blob.shape[1:])
        for i in range(_blob.shape[0]):
            _temp += _blob[i]
        _temp /= _blob.shape[0]
        self.heatmap_visualize(blob_name, _temp)


class Logger:

    def __init__(self, solver=None, show_step_interval=-1, begin_iter=0, log_path=None, visualizer=None, for_test=False):
        self.solver = solver
        self.start_time = time.time()
        if solver is not None:
            self.show_step = solver.test_iter if for_test else solver.display_every
        else:
            self.show_step = show_step_interval
        self.temp_store = OrderedDict()
        self.temp_step = 0
        if solver is not None:
            self.cur_iter = solver.cur_iter()
        else:
            self.cur_iter = begin_iter
        if solver is not None:
            self.max_iter = solver.max_iter
        else:
            self.max_iter = -1
        self.log_path = log_path
        self.logs = OrderedDict()  # dict[iter] = dict[key, value]
        self.vis = visualizer
        self.last_test_result = None
        if self.solver is not None and not for_test:
            self.timer = Timer(inline_print=False)
        else:
            self.timer = None
        if self.log_path is not None:
            try:
                with open(log_path, 'r') as f:
                    for lines in f:  # If logs are available
                        values = lines.split('\t')[:-1]  # iter \t key \t value \t key \t value \t ...
                        if int(values[0]) > self.cur_iter or (for_test and int(values[0]) == self.cur_iter):
                            break
                        self.logs[values[0]] = OrderedDict()
                        for idx in range(int(len(values) / 2)):
                            self.logs[values[0]][values[idx * 2 + 1]] = float(values[idx * 2 + 2])

                self.save_logs()
                self.setup_visualize()
            except IOError:
                pass

    def set_time(self):
        self.start_time = time.time()

    def start(self):
        self.set_time()
        if self.timer is not None:
            self.timer.start(self.max_iter, self.cur_iter)

    def step(self, log_dict, test_cur_iter=-1):
        if self.timer is not None:
            self.timer.tick_timer()
        for k in log_dict.keys():
            if k != 'msg':
                if k not in self.temp_store.keys():
                    self.temp_store[k] = 0.0
                self.temp_store[k] += log_dict[k]
            else:
                self.temp_store['msg'] = log_dict['msg']
        self.temp_step += 1
        if self.show_step != -1 and self.temp_step % self.show_step == 0 and self.temp_step != 0:
            self.temp_step = 0
            for k in self.temp_store.keys():
                if k != 'msg':
                    self.temp_store[k] /= self.show_step
            self.print_logs(self.temp_store, test_cur_iter)
            self.last_test_result = copy.deepcopy(self.temp_store)
            self.temp_store.clear()

    def print_logs(self, log_dict, test_cur_iter=-1):
        """
        Print logs at command line and write logs
        :param log_dict: Dictionary of logs. If you want to feed supplement message, use key 'msg'
        :param test_cur_iter: Indicate current iteration at test phase
        :return:
        """
        self.cur_iter += self.show_step
        if test_cur_iter != -1:
            self.cur_iter = test_cur_iter

        _time = time.time() - self.start_time
        log_str = ''
        if 'msg' in log_dict.keys():
            log_str += '[%s]' % log_dict['msg']
        log_str += '[%s]\n' % time.strftime("%c")
        if self.timer is None:
            log_str += 'Iter %d: %6.3f seconds [%6.3f iter/s]' % (self.cur_iter, _time, self.show_step / _time)
        else:
            r_hour, r_minute, r_seconds = self.timer.left_time()
            log_str += '[%d/%d][%.2f%%][%6.3f sec][%6.3f iter/s]\n[%d hours %d minutes %d seconds left]' %\
                       (self.timer.current_progress, self.timer.whole_number_of_data,
                        float(self.timer.current_progress) / float(self.timer.whole_number_of_data) * 100,
                        _time, self.show_step / _time, r_hour, r_minute, r_seconds)
        print(log_str)

        log_file = None
        if self.log_path is not None:
            log_file = open(self.log_path, 'a')
            log_file.write('%d\t' % self.cur_iter)

        for k in log_dict.keys():
            if k == 'msg':
                continue

            # Append logs dict
            if k not in self.logs.keys():
                self.logs[str(self.cur_iter)] = OrderedDict()
            self.logs[str(self.cur_iter)][k] = float(log_dict[k])

            # Write logs file
            if log_file is not None:
                log_file.write('%s\t%f\t' % (k, float(log_dict[k])))

            # Append visualize
            if self.vis is not None:
                self.vis.line_visualize(k, [self.cur_iter], [log_dict[k]])

            # Print logs
            type_of_k = type(log_dict[k])
            if type_of_k is str:
                print('%+20s: %s' % (k, log_dict[k]))
            elif str(k).find('acc') != -1:
                print('%+20s: %6.3f%%' % (k, log_dict[k]))
            elif type_of_k is int:
                print('%+20s: %d' % (k, log_dict[k]))
            elif type_of_k is float:
                print('%+20s: %9.6f' % (k, log_dict[k]))

        if log_file is not None:
            log_file.write('\n')
        self.start_time = time.time()

    def setup_visualize(self):
        if self.vis is not None:
            visualize_dict = dict()
            for it in self.logs.keys():
                for k in self.logs[it].keys():
                    if k not in visualize_dict.keys():
                        visualize_dict[k] = OrderedDict()
                        visualize_dict[k]['iter'] = list()
                        visualize_dict[k]['value'] = list()
                    visualize_dict[k]['iter'].append(int(it))
                    visualize_dict[k]['value'].append(float(self.logs[it][k]))
            for k in visualize_dict.keys():
                self.vis.line_visualize(k, visualize_dict[k]['iter'], visualize_dict[k]['value'],
                                        update='replace' if self.vis.has_window(k) else 'append')

    def save_logs(self):
        if self.log_path is not None:
            with open(self.log_path, 'w') as f:
                for it in self.logs.keys():
                    temp_str = it + '\t'
                    for k in self.logs[it].keys():
                        temp_str += str(k)
                        temp_str += '\t'
                        temp_str += str(self.logs[it][k])
                        temp_str += '\t'
                    temp_str += '\n'
                    f.write(temp_str)
