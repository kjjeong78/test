from os.path import join, basename
from augmentation import load_configuration, check_and_augment
from util.file_util import deep_search, make_dir, NUMBER_OF_THREADS
from util.util_func import Timer
from multiprocessing.pool import ThreadPool


def tlr_augment_by_num_blobs(image_path, output_path, ext='bmp'):
    image_path = str(image_path).replace('\\', '/')
    output_path = str(output_path).replace('\\', '/')

    image_data = dict()
    image_files = deep_search(image_path, ext)
    n_per_blob = [0] * 5
    for img_path in image_files:
        temp_n_blob = 5
        tl_cls = [int(cl) for cl in basename(img_path).split('(')[1].split(')')[0].split(',')]
        for cl in tl_cls:
            if cl == 4:
                temp_n_blob -= 1
        n_per_blob[temp_n_blob - 1] += 1
        image_data[img_path] = list()
        temp_dict = dict()
        temp_dict['cls'] = temp_n_blob
        image_data[img_path].append(temp_dict)

    max_blob = 0
    n_image_to_gen = dict()

    for n_b in n_per_blob:
        if n_b > max_blob:
            max_blob = n_b

    for blob, n_b in enumerate(n_per_blob):
        ratio = n_b if n_b == 0 else float(max_blob) / float(n_b)
        ratio = int(ratio)
        n_image_to_gen[blob + 1] = ratio

    print('n_per_blob', n_per_blob)
    print('n_image_to_gen', n_image_to_gen)
    # Generate new directories to store dataset
    print('Augmenting dataset %s to %s' % (image_path, output_path))
    make_dir(output_path)

    for idx in range(len(n_image_to_gen)):
        n_image_to_gen[idx + 1] = 30 if n_image_to_gen[idx + 1] > 30 else n_image_to_gen[idx + 1]
    print('n_image_to_gen', n_image_to_gen)

    # Augmenting data
    print('Augmenting data')
    params = load_configuration('config_blob.ini')

    whole = len(image_data)

    timer = Timer()
    timer.start(whole)
    pool = ThreadPool(processes=NUMBER_OF_THREADS)
    threads = list()
    for idx, filename in enumerate(image_data):
        threads.append(
            pool.apply_async(
                check_and_augment,
                (params, join(image_path, filename), output_path, image_data[filename],
                 n_image_to_gen, 0, timer)
            )
        )

    for t in threads:
        t.get()
