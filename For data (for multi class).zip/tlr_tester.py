import caffe
import argparse
import cv2
import numpy as np
import shutil
from os.path import splitext, basename
from os.path import join, basename, isdir
from util.util_func import tlr_preprocessing, tlr_resize_and_pad
from util.caffe_util import Network
from util.file_util import make_dir, deep_search


parser = argparse.ArgumentParser()

parser.add_argument('--input_dir', type=str, help='Path of directory which contains data',
                    default=r'D:\DB\TLR\00.train_01_od_cm_ger_tlr (20.01.14)\tl_crop_day')

parser.add_argument('--network', type=str, help='Path of model',
                    default=r'D:\GoogleDriveBack\StradVision\Utils\PycaffeTrainer\solvers_tlr20\tlr_network.prototxt')

parser.add_argument('--weights', type=str, help='Path of caffemodel',
                    default=r'D:\GoogleDriveBack\StradVision\Utils\PycaffeTrainer\solvers_tlr20\snapshots\network\tlr_99.193')

parser.add_argument('--num_bulb', type=int, help='Number of bulbs',
                    default=5)

parser.add_argument('--num_class', type=int, help='Number of class',
                    default=5)

parser.add_argument('--save', type=str, help='Save images or not',
                    default='false')

parser.add_argument('--gpu', type=int, help='Iteration of snapshots',
                    default=0)

args = parser.parse_args()

args.input_dir = str(args.input_dir).replace('\\', '/')
args.network = str(args.network).replace('\\', '/')
args.weights = str(args.weights).replace('\\', '/')

result_path = './classified_result/s'

if isdir(args.weights):
    files = deep_search(str(args.weights), name_grep='caffemodel')
    args.weights = files[0]

# initialize the nets
caffe.set_device(0)
caffe.set_mode_gpu()
net = Network(model_path=args.network, weights=args.weights, phase=caffe.TEST)
image_list = deep_search(args.input_dir, ext_grep=['png', 'bmp', 'jpg', 'jpeg'])

num_bulb = args.num_bulb
num_class = args.num_class
result_matrix = [[0] * num_class for item in range(num_class)]  # Store Correct, Whole number of samples
result_bulb = [[0] * num_bulb for item in range(num_bulb)]

for i in range(num_bulb):
    make_dir(join(args.input_dir, str(i)))


# do training
num_img = len(image_list)
for idx, img_path in enumerate(image_list):
    origin = cv2.imread(img_path)
    input_tensor = tlr_preprocessing(origin, 16, 80)

    # Run network
    net.blobs['data'].data[...] = input_tensor
    net.forward()
    prob = net.blobs['cls_prob'].data[0]

    # GT Class
    tl = [int(x) for x in splitext(basename(img_path))[0].split('(')[1].split(')')[0].split(',')]

    real_bulb = list()
    n_bulb = 0
    n_predict_bulb = 0
    predict_bulb = list()
    prediction = list()
    for b in range(num_bulb):
        offset = b * num_class
        predict = 0
        for c in range(1, num_class):
            if prob[offset + predict] < prob[offset + c]:
                predict = c
        cls = tl[b]
        prediction.append(predict)
        result_matrix[cls][predict] += 1
        if cls == 4:
            real_bulb.append(0)
        else:
            real_bulb.append(1)
            n_bulb += 1

        if predict == 4:
            predict_bulb.append(0)
        else:
            predict_bulb.append(1)
            n_predict_bulb += 1

    check_bulb = 0
    for r, p in zip(real_bulb, predict_bulb):
        if r == p:
            check_bulb += 1

    result_bulb[n_bulb - 1][n_predict_bulb - 1] += 1

    # for idx_t, t in enumerate(tl):
    #     if t in [2, 3]:
    #         shutil.copy(img_path, join(args.input_dir, str(t), str(prediction[idx_t]) + '_' + basename(img_path)))
    #         break
    # if tl != prediction:
        # print(real_bulb, predict_bulb)
        # print(tl, prediction)
        # cv2.imshow('Image', tlr_resize_and_pad(origin, 64, 320))
        # cv2.waitKey()
    # if check_bulb == len(real_bulb):
    #     result_bulb[n_bulb - 1][0] += 1

    if idx % 1000 == 0 and idx != 0:
        print("Result" + str(idx))
        for c, r in enumerate(result_matrix):
            temp = ''
            temp_sum = 0
            for rr in r:
                temp += str(rr) + '\t'
                temp_sum += rr
            print(temp + str(float(r[c]) / float(temp_sum)))

        for c, r in enumerate(result_bulb):
            temp = ''
            temp_sum = 0
            for rr in r:
                temp += str(rr) + '\t'
                temp_sum += rr
            print(temp + str(temp_sum if temp_sum == 0 else float(r[c]) / float(temp_sum)))

        # for b_idx, b in enumerate(result_bulb):
        #     print(b_idx + 1, b[0], b[1], b[1] if b[1] == 0 else float(b[0]) / float(b[1]))


print("Result" + str(num_img))
for c, r in enumerate(result_matrix):
    temp = ''
    temp_sum = 0
    for rr in r:
        temp += str(rr) + '\t'
        temp_sum += rr
    print(temp + str(float(r[c]) / float(temp_sum)))

for c, r in enumerate(result_bulb):
    temp = ''
    temp_sum = 0
    for rr in r:
        temp += str(rr) + '\t'
        temp_sum += rr
    print(temp + str(temp_sum if temp_sum == 0 else float(r[c]) / float(temp_sum)))

# for b_idx, b in enumerate(result_bulb):
#     print(b_idx + 1, b[0], b[1], b[1] if b[1] == 0 else float(b[0]) / float(b[1]))
