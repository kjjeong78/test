import xml.etree.ElementTree as elemTree
from jinja2 import Environment, FileSystemLoader
from os.path import abspath, basename, dirname
from util.file_util import divide_list, start_task, print_task, NUMBER_OF_THREADS


class XMLReader:

    def __init__(self, xml_path):
        self.xml_dict = dict()
        root = elemTree.parse(xml_path).getroot()

        self.search_recursion(root, self.xml_dict)

    def search_recursion(self, cur_obj, cur_dict, is_list=False):
        # Check is list or not
        if is_list:
            cur_data = cur_dict
        else:
            cur_dict[cur_obj.tag] = dict()
            cur_data = cur_dict[cur_obj.tag]

        # Check have attribute
        if len(cur_obj.attrib) != 0:
            cur_data['attrib'] = dict()
            for attr in cur_obj.attrib:
                cur_data['attrib'][attr] = cur_obj.attrib[attr]

        has_child = False
        check_dict = set()
        for child in cur_obj:
            has_child = True
            if len(cur_obj.findall(child.tag)) == 1:
                self.search_recursion(child, cur_data)
            else:
                if not (child.tag in check_dict):
                    check_dict.add(child.tag)
                    cur_data[child.tag] = list()
                cur_data[child.tag].append(dict())
                self.search_recursion(child, cur_data[child.tag][-1], True)

        if not has_child:
            cur_dict[cur_obj.tag] = cur_obj.text


class XMLWriter:

    def __init__(
            self,
            path,
            width,
            height,
            depth=3,
            database='Unknown',
            segmented=0):
        loader = FileSystemLoader(searchpath="./dict")
        environment = Environment(loader=loader)
        self.annotation_template = environment.get_template('annotation.xml')

        abs_path = abspath(path)

        self.template_parameters = {
            'path': abs_path,
            'filename': basename(abs_path),
            'folder': basename(dirname(abs_path)),
            'width': width,
            'height': height,
            'depth': depth,
            'database': database,
            'segmented': segmented,
            'objects': []
        }

    def add_object(
            self,
            name,
            xmin,
            ymin,
            xmax,
            ymax,
            truncated=0,
            difficult=0):
        self.template_parameters['objects'].append({
            'name': name,
            'xmin': xmin,
            'ymin': ymin,
            'xmax': xmax,
            'ymax': ymax,
            'truncated': truncated,
            'difficult': difficult,
        })

    def save(self, annotation_path):
        with open(annotation_path, 'w') as file:
            content = self.annotation_template.render(
                **self.template_parameters)
            file.write(content)

