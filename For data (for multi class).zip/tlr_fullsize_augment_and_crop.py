from os.path import splitext, join, basename, isfile
from collections import OrderedDict
from augmentation import  load_configuration, check_and_augment
from util.file_util import  deep_search, file_func_mt, make_dir, NUMBER_OF_THREADS
from util.util_func import print_function, Timer
from multiprocessing.pool import ThreadPool
from xml_reader import XMLReader
import cv2


def tlr_fullsize_crop_and_augment(image_path, xml_path, output_path, to_augment=True, target_to_gen=None, ext='jpg',
                                  NUM_CLASS=5, least_size=0):
    image_path = str(image_path).replace('\\', '/')
    xml_path = str(xml_path).replace('\\', '/')
    output_path = str(output_path).replace('\\', '/')

    xmls = deep_search(xml_path, 'xml')
    tl_car_objs = dict()
    tl_car_img_list = list()
    tl_num_per_class = dict()

    tl_off = {0}
    tl_on = {1, 2, 3, 4, 5, 6, 7, 8, 9, 16}
    tl_arr = {10, 11, 12}
    tl_etc = {13, 14, 15}
    tl_ignore = {17}
    tl_num = [0 for i in range(19)]
    tl_blob = [0 for i in range(6)]

    for idx, x in enumerate(xmls):
        k = XMLReader(x).xml_dict
        img_path = join(image_path, splitext(basename(x))[0] + '.' + ext)
        if not isfile(img_path):
            continue
        tls = None
        if 'object' in k['annotation'].keys():
            obj = k['annotation']['object']
            if type(obj) == list:
                tls = [t for t in obj if (t['name'] == 'tl_car' and ('tag' in t.keys()) and t['tag']['is_ignored'] == 'False')]
            elif obj['name'] == 'tl_car' and ('tag' in obj.keys()) and obj['tag']['is_ignored'] == 'False':
                tls = [k['annotation']['object']]

        if tls is not None and len(tls) > 0:
            tls_idx = 0            
            while len(tls) > 0 and tls_idx < len(tls):
                tl_cnt = int(tls[tls_idx]['tag']['tl_cnt'])
                tl_l = list()
                check_ignore = False
                check_is_none = tls[tls_idx]['tag']['is_none'] == 'True'
                for tl_idx, tl_v in enumerate(tls[tls_idx]['tag']['tl_info']['tl']):
                    if tl_idx < tl_cnt:
                        v = int(tl_v['tl'])
                        if v in tl_off:
                            tl_l.append(0)
                        elif v in tl_on:
                            tl_l.append(1)
                        elif v in tl_arr:
                            tl_l.append(2)
                        elif v in tl_etc:
                            tl_l.append(3)
                        if v in tl_ignore:
                            check_ignore = True
                            break
                        # tl_l.append(v)
                    else:
                        tl_l.append(4)
                if check_ignore or check_is_none or float(tls[tls_idx]['bndbox']['xmax']) - float(tls[tls_idx]['bndbox']['xmin']) < least_size:
                    tls.pop(tls_idx)
                else:
                    tls[tls_idx]['clss'] = tl_l
                    t = tls[tls_idx]['bndbox']
                    tls[tls_idx]['pos1'] = [int(round(float(t['xmin']))), int(round(float(t['ymin'])))]
                    tls[tls_idx]['pos2'] = [int(round(float(t['xmax']))), int(round(float(t['ymax'])))]
                    tl_blob[tl_cnt] += 1
                    for tl_idx, tl_v in enumerate(tls[tls_idx]['tag']['tl_info']['tl']):
                        if tl_idx < tl_cnt:
                            v = int(tl_v['tl'])
                            tl_num[v] = tl_num[v] + 1
                    tls_idx += 1
                        
            for tl in tls:
                cnt = tl['tag']['tl_cnt']
                for t in tl['clss']:
                    cls = str(cnt) + '_' + str(t)
                    try:
                        tl_num_per_class[cls] += 1
                    except KeyError:
                        tl_num_per_class[cls] = 1
            tl_car_objs[splitext(basename(x))[0] + '.jpg'] = tls
            tl_car_img_list.append(img_path)

        print_function('%d/%d' % (idx + 1, len(xmls)))

    print('\nNum per class', tl_num_per_class)
    print('\nNum per signal', tl_num)
    print('\nNum per blob', tl_blob)
    # Sorting num per class
    tl_num_per_class_sort = OrderedDict()
    max_num = 0
    for t_c in tl_num_per_class:
        count = 0
        for t_c2 in tl_num_per_class:
            if tl_num_per_class[t_c] < tl_num_per_class[t_c2]:
                count += 1
        tl_num_per_class_sort[t_c] = count
        if tl_num_per_class_sort[t_c] == 0:
            max_num = tl_num_per_class[t_c]

    # Assign temporary class which have lowest number of data
    tl_num_per_min_class = dict()
    for tls in tl_car_objs:
        for tl in tl_car_objs[tls]:
            min_idx = str(tl['tag']['tl_cnt']) + '_' + str(tl['clss'][0])
            for t in tl['clss'][1:]:
                t = str(tl['tag']['tl_cnt']) + '_' + str(t)
                if tl_num_per_class_sort[t] > tl_num_per_class_sort[min_idx]:
                    min_idx = t
            tl['cls'] = min_idx
            try:
                tl_num_per_min_class[min_idx] += 1
            except KeyError:
                tl_num_per_min_class[min_idx] = 1

    make_dir(output_path)

    if not to_augment:

        def crop_and_paste(src, dst):
            img = cv2.imread(src)
            meta = tl_car_objs[splitext(basename(src))[0] + '.jpg']

            for idx, tl in enumerate(meta):
                xmin = int(round(float(tl['bndbox']['xmin'])))
                xmax = int(round(float(tl['bndbox']['xmax'])))
                ymin = int(round(float(tl['bndbox']['ymin'])))
                ymax = int(round(float(tl['bndbox']['ymax'])))
                cropped = img[ymin:ymax, xmin:xmax, :]
                cls = ''
                for cl in tl['clss']:
                    cls += str(cl) + ','
                cv2.imwrite(splitext(dst)[0] + '_' + str(idx) + '_(' + cls[:-1] + ').bmp', cropped)

        file_func_mt(crop_and_paste, tl_car_img_list, output_path)

    else:
        # Generate new directories to store dataset
        print('Augmenting dataset %s to %s' % (image_path, output_path))

        # Augmenting data
        print('Augmenting data')
        params = load_configuration('config_real.ini')
        num_img_to_gen = dict()
        target_to_gen = target_to_gen if target_to_gen is not None else max_num
        for n in tl_num_per_class:
            num_img_to_gen[n] = int(round(float(target_to_gen) / float(tl_num_per_class[n])))
            if num_img_to_gen[n] < 1:
                num_img_to_gen[n] = 1
            if num_img_to_gen[n] > 100:
                num_img_to_gen[n] = int((float(num_img_to_gen[n] - 100) / 100.0) * 2 + 100)
            if num_img_to_gen[n] < 10:
                num_img_to_gen[n] *= 2
        print('Number of image to gen per class', num_img_to_gen)

        timer = Timer()
        timer.start(len(tl_car_objs))
        pool = ThreadPool(processes=NUMBER_OF_THREADS)
        threads = list()
        for idx, filename in enumerate(tl_car_objs):
            threads.append(
                pool.apply_async(
                    check_and_augment,
                    (params, join(image_path, filename), output_path, tl_car_objs[filename],
                     num_img_to_gen, 15, timer, True)
                )
            )

        for t in threads:
            t.get()

    output_files = deep_search(output_path, ['bmp', 'jpg', 'png', 'jpeg'])
    generated_num_per_cls = [0] * NUM_CLASS
    generated_num_per_blobs = [0] * (NUM_CLASS + 1)
    for f in output_files:
        tl = [int(cl) for cl in basename(f).split('(')[1].split(')')[0].split(',')]
        tl_cnt = 5
        for t in tl:
            generated_num_per_cls[t] += 1
            if t == 4:
                tl_cnt -= 1
        generated_num_per_blobs[tl_cnt] += 1

    print('\nGenerated class per blob', generated_num_per_cls)
    print('Generated per num blobs', generated_num_per_blobs[1:])
