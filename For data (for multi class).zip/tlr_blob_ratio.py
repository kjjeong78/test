import caffe
import argparse
import cv2
import numpy as np
import shutil
from os.path import splitext, basename
from os.path import join, basename, isdir
from util.caffe_util import Network
from util.file_util import make_dir, deep_search


parser = argparse.ArgumentParser()

parser.add_argument('--input_dir', type=str, help='Path of directory which contains data',
                    default=r'D:\DB\TLR\51.cm_ger_tstld_rework_tlr (19.12.20)\tl_crop')

parser.add_argument('--num_bulb', type=int, help='Number of bulbs',
                    default=5)

args = parser.parse_args()

args.input_dir = str(args.input_dir).replace('\\', '/')

image_list = deep_search(args.input_dir, ext_grep=['png', 'bmp', 'jpg', 'jpeg'])
print('Read %d images' % len(image_list))

num_blob = args.num_bulb
blob_ratio_mean = [0] * num_blob
number_of_blob = [0] * num_blob


def resize_and_make_border(img):
    WIDTH = 32
    HEIGHT = 160
    height, width, channel = img.shape
    resized_width = WIDTH
    resized_height = int(float(height) * (float(resized_width) / float(width)))
    resized_height = resized_height if resized_height < HEIGHT else HEIGHT
    img = cv2.resize(img, (int(resized_width), int(resized_height)), interpolation=cv2.INTER_LINEAR)
    pad = HEIGHT - resized_height
    img = cv2.copyMakeBorder(img, 0, int(pad), 0, 0, cv2.BORDER_CONSTANT, value=[102.980103, 115.946503, 122.771698])
    return img


# do training
num_img = len(image_list)
for idx, img_path in enumerate(image_list):
    origin = cv2.imread(img_path)
    h, w, c = origin.shape

    # GT Class
    tl = [int(x) for x in splitext(basename(img_path))[0].split('(')[1].split(')')[0].split(',')]

    n_blob = 0
    for b in range(num_blob):
        cls = tl[b]
        if cls != 4:
            n_blob += 1

    blob_ratio_mean[n_blob - 1] += float(w) / float(h)
    number_of_blob[n_blob - 1] += 1

    if idx != 0 and idx % 1000 == 0:
        temp_ratio = [0] * num_blob
        for i in range(num_blob):
            temp_ratio[i] = 0 if number_of_blob[i] == 0 else blob_ratio_mean[i] / float(number_of_blob[i])
        print(idx, temp_ratio)

for i in range(num_blob):
    blob_ratio_mean[i] /= float(number_of_blob[i])

print('Blob ratio', blob_ratio_mean)
