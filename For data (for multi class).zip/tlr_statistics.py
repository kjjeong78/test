from os.path import join, basename, splitext, dirname
import shutil
import argparse
from annotation_generator import generate_annotations
from util.file_util import gather_dirs, gather_files, deep_search, file_func_mt, make_dir, NUMBER_OF_THREADS


parser = argparse.ArgumentParser()

parser.add_argument('--image_path', type=str, help='Source path of images',
                    default=r'F:\TLR\DB\train\tl_resize_day_rnd_crop0.1_min16')

args = parser.parse_args()

args.image_path = str(args.image_path).replace('\\', '/')
images = deep_search(args.image_path, ext_grep=['jpg', 'png', 'bmp', 'jpeg'])
image_names = [splitext(basename(name))[0] for name in images]

cls_statistics = dict()

cls_statistics['1blob'] = 0
cls_statistics['2blob'] = 0
cls_statistics['3blob'] = 0
cls_statistics['4blob'] = 0
cls_statistics['5blob'] = 0

for idx, i_n in enumerate(image_names):
    cls = [int(c) for c in i_n.split('(')[1].split(')')[0].split(',')]
    check_blob = 5
    for c in cls:
        if c == 4:
            check_blob -= 1
        try:
            cls_statistics[c] += 1
        except KeyError:
            cls_statistics[c] = 1

    if check_blob == 1:
        cls_statistics['1blob'] += 1
    elif check_blob == 2:
        cls_statistics['2blob'] += 1
    elif check_blob == 3:
        cls_statistics['3blob'] += 1
    elif check_blob == 4:
        cls_statistics['4blob'] += 1
    elif check_blob == 5:
        cls_statistics['5blob'] += 1

print(cls_statistics)
