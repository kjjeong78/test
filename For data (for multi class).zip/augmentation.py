#!/usr/bin/env python
#-*-coding:utf-8-*-
import configparser
import random
import ntpath
import os
from copy import deepcopy
from os.path import dirname, basename, splitext, join, isdir, isfile
import time
from collections import OrderedDict
import cv2
from util.file_util import gather_files, make_dir, NUMBER_OF_THREADS
from util.util_func import print_function, print_task
from multiprocessing.pool import ThreadPool
import numpy as np
import math


pool = ThreadPool(processes=NUMBER_OF_THREADS)


def union(a, b):
    x = min(a[0], b[0])
    y = min(a[1], b[1])
    w = max(a[0] + a[2], b[0] + b[2]) - x
    h = max(a[1] + a[3], b[1] + b[3]) - y
    return (x, y, w, h)


def intersection(a, b):
    x = max(a[0], b[0])
    y = max(a[1], b[1])
    w = min(a[0] + a[2], b[0] + b[2]) - x
    h = min(a[1] + a[3], b[1] + b[3]) - y
    if w < 0 or h < 0:
        return (0, 0, 0, 0)
    return (x, y, w, h)


class MultiOrderedDict(OrderedDict):

    def __setitem__(self, key, value):
        # raise Exception()
        if key in self:
            if isinstance(value, list):
                self[key].extend(value)
                return
            elif isinstance(value, str):
                return
        super(MultiOrderedDict, self).__setitem__(key, value)


class GlyphInfo(object):
    __slots__ = ["width", "height", "bearingX", "bearingY", "advance"]


class ConfigParameters(object):
    # image
    __slots__ = ["width", "height", "channels", "margin_w", "margin_h",
                 "foreground", "background",
                 "prob_3d_rotation", "rotation_angle_x", "rotation_angle_y", "rotation_angle_z",
                 "prob_thickness", "thickness",
                 "prob_outline", "outline",
                 "prob_gaussian_blur", "gaussian_blur", "gaussian_kernel",
                 "prob_motion_blur", "motion_angle", "motion_length",
                 "prob_gaussian_noise", "gaussian_noise",
                 "prob_resample", "resample_ratio",
                 "prob_jpeg_artifact", "jpeg_quality",
                 "prob_global_intensity", "global_intensity",
                 "prob_local_intensity", "local_intensity", "local_average",
                 "prob_variable_size", "variable_size",
                 "prob_rotation", "rotating_range"
                 ]


def readconfig(filename):
    cp = configparser.ConfigParser()
    cp.read(filename)

    # print('filename=', filename)

    params = ConfigParameters()
    # [image]
    params.width = int(cp['image']['width'])
    params.height = int(cp['image']['height'])
    params.channels = int(cp['image']['channels'])
    params.margin_w = int(cp['image']['margin_w'])
    params.margin_h = int(cp['image']['margin_h'])

    # [distribution]
    params.prob_3d_rotation = cp['distribution']['prob_3d_rotation'].split()

    params.rotation_angle_x = cp['distribution']['rotation_angle_x'].split()
    params.rotation_angle_y = cp['distribution']['rotation_angle_y'].split()
    params.rotation_angle_z = cp['distribution']['rotation_angle_z'].split()

    params.prob_thickness = cp['distribution']['prob_thickness'].split()
    params.thickness = cp['distribution']['thickness'].split()

    params.prob_gaussian_blur = cp['distribution']['prob_gaussian_blur'].split()
    params.gaussian_blur = cp['distribution']['gaussian_blur'].split()
    params.gaussian_kernel = cp['distribution']['gaussian_kernel'].split()

    params.prob_motion_blur = cp['distribution']['prob_motion_blur'].split()
    params.motion_angle = cp['distribution']['motion_angle'].split()
    params.motion_length = cp['distribution']['motion_length'].split()

    params.prob_gaussian_noise = cp['distribution']['prob_gaussian_noise'].split()
    params.gaussian_noise = cp['distribution']['gaussian_noise'].split()

    params.prob_resample = cp['distribution']['prob_resample'].split()
    params.resample_ratio = cp['distribution']['resample_ratio'].split()

    params.prob_jpeg_artifact = cp['distribution']['prob_jpeg_artifact'].split()
    params.jpeg_quality = cp['distribution']['jpeg_quality'].split()

    params.prob_global_intensity = cp['distribution']['prob_global_intensity'].split()
    params.global_intensity = cp['distribution']['global_intensity'].split()

    params.prob_local_intensity = cp['distribution']['prob_local_intensity'].split()
    params.local_intensity = cp['distribution']['local_intensity'].split()
    params.local_average = cp['distribution']['local_average'].split()

    params.prob_variable_size = cp['distribution']['prob_variable_size'].split()
    params.variable_size = cp['distribution']['variable_size'].split()

    params.prob_rotation = cp['distribution']['prob_rotation'].split()
    params.rotating_range = cp['distribution']['rotating_range'].split()

    return params


def bitmap2array(bitmap):
    width = bitmap.width
    rows = bitmap.rows
    pitch = bitmap.pitch
    data = []
    for r in range(rows):
        data.extend(bitmap.buffer[r * pitch:r * pitch + width])
    return data


def load_configuration(filename):
    # print('Load configurations')
    # Read the INI file & load configuration parameters
    params = readconfig(filename)

    return params
    # return character_bank, params, foreground, background


def prob(distribution):
    p = 0
    # print 'distribution=', distribution
    if distribution[0] == 'gaussian':
        # print 'gaussian'
        mu = float(distribution[1])
        sigma = float(distribution[2])
        # print 'mu=', mu, '  sigma=', sigma
        p = random.gauss(mu, sigma)
    elif distribution[0] == 'uniform':
        # print 'uniform'
        p = random.uniform(float(distribution[1]), float(distribution[2]))
    elif distribution[0] == 'discrete':
        # print 'discrete'
        seq = distribution[1:]
        prob_list = [float(i) for i in seq[0:][::2]]
        elem_list = [float(i) for i in seq[1:][::2]]
        prob_list = [float(i) / sum(prob_list)
                     for i in prob_list]    # normalize
        p = np.random.choice(elem_list, 1, prob_list)[0]
    elif distribution[0] == 'const':
        p = float(distribution[1])
    else:
        p = 0
    return p


def transform_image(input, left, top, right, bottom, thetax, thetay, thetaz, deltax, deltay, deltaz, f, pad):
    thetax = np.deg2rad(thetax)
    thetay = np.deg2rad(thetay)
    thetaz = np.deg2rad(thetaz)

    # get width and height for ease of use in matrices
    h = input.shape[0]
    w = input.shape[1]

    # Projection 2D -> 3D matrix
    A1 = np.array([[1, 0, -w / 2],
                   [0, 1, -h / 2],
                   [0, 0, 0],
                   [0, 0, 1]])

    # Rotation matrices around the X, Y, and Z axis
    RX = np.array([[1, 0, 0, 0],
                   [0, np.cos(thetax), -np.sin(thetax), 0],
                   [0, np.sin(thetax), np.cos(thetax), 0],
                   [0, 0, 0, 1]])
    RY = np.array([[np.cos(thetay), 0, -np.sin(thetay), 0],
                   [0, 1, 0, 0],
                   [np.sin(thetay), 0, np.cos(thetay), 0],
                   [0, 0, 0, 1]])
    RZ = np.array([[np.cos(thetaz), -np.sin(thetaz), 0, 0],
                   [np.sin(thetaz), np.cos(thetaz), 0, 0],
                   [0, 0, 1, 0],
                   [0, 0, 0, 1]])

    # Composed rotation matrix with (RX, RY, RZ)
    R = np.matmul(np.matmul(RX, RY), RZ)

    # Translation matrix
    T = np.array([[1, 0, 0, deltax],
                  [0, 1, 0, deltay],
                  [0, 0, 1, deltaz],
                  [0, 0, 0, 1]])

    # 3D -> 2D matrix
    A2 = np.array([[f, 0, (w + pad * 2) / 2, 0],
                   [0, f, (h + pad * 2) / 2, 0],
                   [0, 0,   1, 0]])

    # Final transformation matrix
    trans = np.matmul(A2, np.matmul(T, np.matmul(R, A1)))

    # Apply matrix transformation
    # cv2.warpPerspective(input, output, trans, input.size(), INTER_LANCZOS4);
    new_size = (int(w + pad * 2), int(h + pad * 2))
    output = cv2.warpPerspective(
        input, trans, new_size, flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    # output_mask_i = cv2.warpPerspective(mask_i, trans, new_size, flags=cv2.INTER_LINEAR)
    # output_mask_o = cv2.warpPerspective(mask_o, trans, new_size,
    # flags=cv2.INTER_LINEAR)

    pts = np.array([[left, top], [right, bottom]], dtype='float32')
    output_pts = cv2.perspectiveTransform(np.array([pts]), trans)

    # print pts
    # print output_pts

    return output, output_pts


def find_range(img):
    left = img.shape[1]
    top = img.shape[0]
    right = 0
    bottom = 0

    for y in range(img.shape[0]):
        for x in range(img.shape[1]):
            if img[y, x] != 0:
                left = min(left, x)
                right = max(right, x)
                top = min(top, y)
                bottom = max(bottom, y)

    return left, top, right, bottom


def get_gaussian_param(params):
    gaussian_sigma = float(max(prob(params.gaussian_blur), 1))
    gaussian_kernel = int(prob(params.gaussian_kernel))
    if gaussian_kernel % 2 == 0:
        gaussian_kernel = gaussian_kernel + 1
    return gaussian_sigma, gaussian_kernel


def get_motion_blur_param(params):
    motion_angle = float(prob(params.motion_angle))
    motion_length = int(prob(params.motion_length))
    if motion_length < 1:
        motion_length = 1
    kernel = np.zeros((motion_length, motion_length))
    kernel[int((motion_length - 1) / 2), :] = np.ones(motion_length)
    kernel = kernel / motion_length
    M = cv2.getRotationMatrix2D((motion_length / 2, motion_length / 2), motion_angle, 1)
    kernel = cv2.warpAffine(kernel, M, (motion_length, motion_length))
    kernel = cv2.normalize(kernel, kernel, norm_type=cv2.NORM_L1)
    return kernel


def get_noise_param(params, height, width):
    gaussian_sigma = float(prob(params.gaussian_noise))
    noise = np.zeros((height, width, 3))
    cv2.randn(noise, 0, gaussian_sigma)
    return noise


def get_resampling_param(params, height, width):
    sampling_rate = float(prob(params.resample_ratio))
    if sampling_rate < 0.2:
        sampling_rate = 0.2
    new_width = int(width * sampling_rate + 0.5)
    new_height = int(height * sampling_rate + 0.5)
    return new_width, new_height


def get_jpeg_artifact_param(params):
    return int(prob(params.jpeg_quality))


def get_global_intensity_param(params):
    return max(float(prob(params.global_intensity)), 0.1)


def get_local_intensity_param(params, height, width):
    intensity_map = np.zeros(
        (height, width), dtype=np.float32)
    for y in range(height):
        for x in range(width):
            intensity_map[y, x] = float(
                max(prob(params.local_intensity), 0.1))

    k = int(prob(params.local_average))
    intensity_map = cv2.blur(intensity_map, (k, k))
    intensity_map = np.expand_dims(intensity_map, axis=2)

    return intensity_map


def get_rotation_param(params, height, width):
    return cv2.getRotationMatrix2D((width / 2, height / 2), prob(params.rotating_range), 1.0)


def get_resize_param(params, height, width):
    size = (prob(params.variable_size))
    min_s = min(width, height)
    max_s = max(width, height)
    f = size / float(max_s)
    if f * min_s < 24:
        f = size / min_s
    new_w = int(width * f)
    new_h = int(height * f)

    return new_w, new_h


def do_gaussian_blur(img, kernel, sigma):
    if img is None:
        return None
    else:
        return cv2.GaussianBlur(img, (kernel, kernel), sigma).astype(np.uint8)


def do_motion_blur(img, kernel):
    if img is None:
        return None
    else:
        img = cv2.filter2D(img, -1, kernel)
        return img


def do_noise(img, noise):
    if img is None:
        return None
    else:
        img = img + noise * 255
        img[img > 255] = 255.0
        img[img < 0] = 0
        return img.astype(np.uint8)


def do_resample(img, new_width, new_height):
    if img is None:
        return None
    else:
        resample = cv2.resize(
            img, (new_width, new_height), interpolation=cv2.INTER_AREA)
        img = cv2.resize(resample, (img.shape[1], img.shape[0]),
                         interpolation=cv2.INTER_AREA)
        return img.astype(np.uint8)


def do_jpeg_artifact(img, jpeg_quality):
    if img is None:
        return None
    else:
        _, buf = cv2.imencode(
            ".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, jpeg_quality])
        return cv2.imdecode(buf, cv2.IMREAD_COLOR)


def do_global_intensity(img, global_intensity):
    if img is None:
        return None
    else:
        img = img.astype(np.float)
        img *= global_intensity
        img[img > 255] = 255
        img[img < 0] = 0
        return img.astype(np.uint8)


def do_local_intensity(img, local_intensity):
    if img is None:
        return None
    else:
        img = img.astype(np.float)
        img *= local_intensity
        img[img > 255] = 255
        img[img < 0] = 0
        return img.astype(np.uint8)


def do_rotation(img, rot_mat):
    if img is None:
        return None
    else:
        return cv2.warpAffine(img, rot_mat, (img.shape[1], img.shape[0]))


def do_resize(img, new_width, new_height):
    if img is None:
        return None
    else:
        return cv2.resize(img, (new_width, new_height),
                          interpolation=cv2.INTER_LINEAR)


def augment_image(img_path, dst_path, params, num_image_to_gen, gt_path=None, gt_dst=None, pad=None, pad_ratio=0.0,
                  rnd_crop=False):
    if type(img_path) is str:
        img = cv2.imread(img_path)
    else:
        img = img_path

    if num_image_to_gen == 0 or img is None:
        return

    make_dir(dirname(dst_path))
    gt = None
    if gt_path is not None:
        gt = cv2.imread(gt_path)
        make_dir(dirname(gt_dst))

    if gt is not None and (gt.shape[0] != img.shape[0] or gt.shape[1] != img.shape[1]):
        print('GT and Image size are different (%s, %s)' % (basename(gt_path), basename(img_path)))

    for img_idx in range(num_image_to_gen):
        output = img
        output_gt = gt

        height = output.shape[0]
        width = output.shape[1]

        if img_idx != 0:

            # gaussian blur
            if prob(params.prob_gaussian_blur):
                gaussian_sigma, gaussian_kernel = get_gaussian_param(params)
                output = do_gaussian_blur(output, gaussian_kernel, gaussian_sigma)
                output_gt = do_gaussian_blur(output_gt, gaussian_kernel, gaussian_sigma)

            # motion blur
            if prob(params.prob_motion_blur):
                kernel = get_motion_blur_param(params)
                output = do_motion_blur(output, kernel)
                output_gt = do_motion_blur(output_gt, kernel)

            # noise
            if prob(params.prob_gaussian_noise):
                noise = get_noise_param(params, height, width)
                output = do_noise(output, noise)
                output_gt = do_noise(output_gt, noise)

            # resample
            if prob(params.prob_resample):
                new_width, new_height = get_resampling_param(params, height, width)
                output = do_resample(output, new_width, new_height)
                output_gt = do_resample(output_gt, new_width, new_height)

            # jpeg artifact
            if prob(params.prob_jpeg_artifact):
                jpeg_quality = get_jpeg_artifact_param(params)
                output = do_jpeg_artifact(output, jpeg_quality)
                output_gt = do_jpeg_artifact(output_gt, jpeg_quality)

            # global intensity
            if prob(params.prob_global_intensity):
                global_intensity = get_global_intensity_param(params)
                output = do_global_intensity(output, global_intensity)
                output_gt = do_global_intensity(output_gt, global_intensity)

            # local intensity
            if prob(params.prob_local_intensity):
                intensity_map = get_local_intensity_param(params, height, width)
                output = do_local_intensity(output, intensity_map)
                output_gt = do_local_intensity(output_gt, intensity_map)

            # Rotation
            if prob(params.prob_rotation):
                rot_mat = get_rotation_param(params, height, width)
                output = do_rotation(output, rot_mat)
                output_gt = do_rotation(output_gt, rot_mat)

            # Resize
            if prob(params.prob_variable_size):
                new_width, new_height = get_resize_param(params, height, width)
                output = do_resize(output, new_width, new_height)
                output_gt = do_resize(output_gt, new_width, new_height)

        if np.mean(cv2.mean(output)) < 10:
            pass

        if pad is not None:
            temp_pad = pad - int(round(float((width) * pad_ratio)))
            if temp_pad < 0:
                temp_pad = 0

            crop = [0] * 4
            if rnd_crop:
                for c_i in range(4):
                    if c_i in [0, 1]:
                        crop[c_i] = random.randint(-int(float(width) * 0.05), int(float(width) * 0.15))
                    if c_i in [2, 3]:
                        crop[c_i] = random.randint(-int(float(width) * 0.1), int(float(width) * 0.1))
                    if crop[c_i] > temp_pad:
                        crop[c_i] = temp_pad
                    if crop[c_i] < -temp_pad:
                        crop[c_i] = -temp_pad

            if temp_pad != 0:
                output = output[(temp_pad - crop[0]):-(temp_pad - crop[1] + 1), (temp_pad - crop[2]):-(temp_pad - crop[3] + 1), :]
            if output_gt is not None:
                if temp_pad != 0:
                    output_gt = output_gt[(temp_pad - crop[0]):-(temp_pad - crop[1] + 1), (temp_pad - crop[2]):-(temp_pad - crop[3] + 1), :]

        if output is not None and output.shape[0] > 0 and output.shape[1] > 0:
            index = '{:04d}'.format(img_idx)
            file_name, ext = splitext(basename(dst_path))
            output_path = os.path.join(dirname(dst_path), file_name + '_' + str(index) + ext)
            cv2.imwrite(output_path, output)
        else:
            if output is None:
                print('Output image is None [%s]' % dst_path)
            else:
                print(img.shape, output.shape)
                print('Output image size is 0 [%s]' % dst_path)

        if gt is not None:
            index = '{:04d}'.format(img_idx)
            file_name, ext = splitext(basename(gt_dst))
            output_path = os.path.join(dirname(gt_dst), file_name + '_' + str(index) + ext)
            cv2.imwrite(output_path, output_gt)


def check_and_augment(params, img_path, dst_dir, image_data, num_img_to_gen_per_class, pad=15, timer=None, rnd_crop=False):
    """
    src_list, src_dst and gt_list, gt_dst must need to be aligned
    :param params:
    :param img_path:
    :param dst_dir:
    :param image_data:
    :param num_img_to_gen_per_class:
    :param pad:
    :param timer:
    :return:
    """

    img = cv2.imread(img_path)

    if not isfile(img_path) or img is None:
        print('Cannot read %s' % img_path)
        return False
    img_height, img_width = img.shape[:2]

    for idx, i_d in enumerate(image_data):
        # Check min pad
        # Pos1 = Left Top, Pos2 = Right Bottom
        temp_pad = pad
        try:
            if i_d['pos1'][0] - temp_pad < 0:
                temp_pad = i_d['pos1'][0]
            if i_d['pos1'][1] - temp_pad < 0:
                temp_pad = i_d['pos1'][1]

            if i_d['pos2'][0] + temp_pad > img_width:
                temp_pad = img_width - i_d['pos2'][0]
            if i_d['pos2'][1] + temp_pad > img_height:
                temp_pad = img_height - i_d['pos2'][1]

            roi = img[i_d['pos1'][1] - temp_pad:i_d['pos2'][1] + temp_pad,
                      i_d['pos1'][0] - temp_pad:i_d['pos2'][0] + temp_pad, :]
        except KeyError:
            roi = img

        try:
            cls = ''
            for cl in i_d['clss']:
                cls += str(cl) + ','
            cls = cls[:-1]
            num_to_gen = num_img_to_gen_per_class if type(num_img_to_gen_per_class) is int else num_img_to_gen_per_class[i_d['cls']]
            augment_image(roi, join(dst_dir, str(i_d['cls']), splitext(basename(img_path))[0] + ('_%02d_(' % idx) + cls + ').bmp'),
                          params, num_to_gen, pad=temp_pad, pad_ratio=0.0, rnd_crop=rnd_crop)
        except KeyError:
            num_to_gen = num_img_to_gen_per_class if type(num_img_to_gen_per_class) is int else num_img_to_gen_per_class[i_d['cls']]
            augment_image(roi, join(dst_dir, str(i_d['cls']), splitext(basename(img_path))[0] + ('_%02d_' % idx) + '.bmp'),
                          params, num_to_gen, pad=temp_pad, pad_ratio=0.0, rnd_crop=rnd_crop)

    if timer is not None:
        timer.tick_timer()

    return True


def augment(params, src_list, src_dst, num_img_to_gen, least_img, min_size=0, aspect_ratio_limit=0,
            gt_list=None, gt_dst=None):
    """
    src_list, src_dst and gt_list, gt_dst must need to be aligned
    :param params:
    :param src_list:
    :param src_dst:
    :param num_img_to_gen:
    :param least_img:
    :param min_size:
    :param aspect_ratio_limit:
    :param gt_list:
    :param gt_dst:
    :return:
    """
    random.seed(time.time())

    img_list = []
    dst_list = []
    gt_img_list = []
    if gt_list is None:
        gt_img_list = None
    gt_dst_list = []
    if gt_dst is None:
        gt_dst_list = None

    if type(src_dst) is not list and not isdir(src_dst):
        print('src_dst must be list of destination or directory')
        exit(1)
    if gt_dst is not None and type(gt_dst) is not list and not isdir(gt_dst):
        print('gt_dst must be list of destination or directory')
        exit(1)

    for idx, img_path in enumerate(src_list):
        if min_size != 0 or aspect_ratio_limit != 0:
            img = cv2.imread(img_path)
            height, width = img.shape[:2]
            if height < min_size or width < min_size:
                continue
            if width > height:
                if float(width) / float(height) > aspect_ratio_limit:
                    continue
            else:
                if float(height) / float(width) > aspect_ratio_limit:
                    continue
        img_list.append(img_path)
        if gt_dst_list is not None:
            gt_img_list.append(gt_list[idx])
        if gt_list is not None and basename(img_path) != basename(gt_list[idx]):
            print('Image and GT image names are must be same')
            exit(1)
        if type(src_dst) is list:
            dst_list.append(src_dst[idx])
        else:
            dst_list.append(join(src_dst, basename(img_path)))

        if gt_dst is not None:
            if type(gt_dst) is list:
                gt_dst_list.append(gt_dst[idx])
            else:
                gt_dst_list.append(join(gt_dst, basename(img_path)))

    num_sample = len(img_list)

    if num_sample < least_img:
        return False

    # num_images = int(math.ceil(float(max_img) / float(num_sample)))

    threads = list()
    if gt_list is not None and gt_dst is not None:
        for idx, (img_path, dst_path, gt_img_path, gt_dst_path) in enumerate(zip(img_list, dst_list, gt_img_list, gt_dst_list)):
            threads.append(
                pool.apply_async(
                    augment_image,
                    (img_path, dst_path, params, num_img_to_gen, gt_img_path, gt_dst_path)
                )
            )
    else:
        for idx, (img_path, dst_path) in enumerate(zip(img_list, dst_list)):
            threads.append(
                pool.apply_async(
                    augment_image,
                    (img_path, dst_path, params, num_img_to_gen)
                )
            )

    done = 0
    for t in threads:
        t.get()
        print_function('%d/%d' % (done + 1, len(img_list)))
        done += 1
    print()

    return True
