import caffe
import argparse
import cv2
import numpy as np
from os.path import splitext, basename
from os.path import join, basename, isdir
from util.util_func import tlr_preprocessing
from util.caffe_util import Network
from util.file_util import make_dir, deep_search


parser = argparse.ArgumentParser()

parser.add_argument('--input_dir', type=str, help='Path of directory which contains data',
                    default=r'C:\svnet3\tlr')

parser.add_argument('--network', type=str, help='Path of model',
                    default=r'D:\GoogleDriveBack\StradVision\TLR\Models\tlr04\test.prototxt')

parser.add_argument('--weights', type=str, help='Path of caffemodel',
                    default=r'D:\GoogleDriveBack\StradVision\TLR\Models\tlr04\tlr_iter_497001.caffemodel')

parser.add_argument('--num_bulb', type=int, help='Number of bulbs',
                    default=5)

parser.add_argument('--num_class', type=int, help='Number of class',
                    default=5)

parser.add_argument('--save', type=str, help='Save images or not',
                    default='false')

parser.add_argument('--gpu', type=int, help='Iteration of snapshots',
                    default=0)

args = parser.parse_args()

args.input_dir = str(args.input_dir).replace('\\', '/')
args.network = str(args.network).replace('\\', '/')
args.weights = str(args.weights).replace('\\', '/')

result_path = './classified_result/s'

if isdir(args.weights):
    files = deep_search(str(args.weights), name_grep='caffemodel')
    args.weights = files[0]

# initialize the nets
caffe.set_device(0)
caffe.set_mode_gpu()
net = Network(model_path=args.network, weights=args.weights, phase=caffe.TEST)
image_list = deep_search(args.input_dir, ext_grep=['png', 'bmp', 'jpg', 'jpeg'])

num_bulb = args.num_bulb
num_class = args.num_class
result_matrix = [[0] * num_class for item in range(num_class)]  # Store Correct, Whole number of samples
result_bulb = [[0] * num_bulb for item in range(num_bulb)]


# do training
num_img = len(image_list)
for idx, img_path in enumerate(image_list):
    origin = cv2.imread(img_path)
    input_tensor = tlr_preprocessing(origin)

    # Run network
    net.blobs['data'].data[...] = input_tensor
    net.forward()
    prob = net.blobs['cls_prob'].data[0]

    n_predict_bulb = 0
    predict_bulb = list()
    prediction = list()
    for b in range(num_bulb):
        offset = b * num_class
        predict = 0
        for c in range(1, num_class):
            if prob[offset + predict] < prob[offset + c]:
                predict = c
        prediction.append(predict)

        if predict == 4:
            predict_bulb.append(0)
        else:
            predict_bulb.append(1)
            n_predict_bulb += 1

    print(prediction)
    cv2.imshow('Image', origin)
    cv2.waitKey()

