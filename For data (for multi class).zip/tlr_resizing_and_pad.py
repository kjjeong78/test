from os.path import join, basename, splitext, dirname
from util.file_util import deep_search, file_func_mt, make_dir
from util.util_func import tlr_resize_and_pad, tlr_cut_and_return
import cv2


def tlr_resize_and_padding(image_path, output_path, ext='bmp'):
    image_path = str(image_path).replace('\\', '/')
    output_path = str(output_path).replace('\\', '/')
    make_dir(output_path)

    tl_images = deep_search(image_path, ext)    

    def resize_pad_and_paste(src, dst):
        img = cv2.imread(src)
        #img = tlr_resize_and_pad(img, 32, 160)
        image_names = splitext(dst)[0]
        dst0 = image_names + '_0' + '.bmp'
        dst1 = image_names + '_1' + '.bmp'
        dst2 = image_names + '_2' + '.bmp'
        dst3 = image_names + '_3' + '.bmp'
        dst4 = image_names + '_4' + '.bmp'
        total_dst = (dst0, dst1, dst2, dst3, dst4)
        
        cls = [int(c) for c in src.split('(')[1].split(')')[0].split(',')]
        check_blob = 5
        for c in cls:
            if c == 4:
                check_blob -= 1
      
        results = tlr_cut_and_return(img, check_blob)
        for idx in range(len(results)):
            cv2.imwrite(total_dst[idx], results[idx])

    file_func_mt(resize_pad_and_paste, tl_images, output_path)

